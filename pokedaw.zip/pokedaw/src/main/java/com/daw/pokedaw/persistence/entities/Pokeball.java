package com.daw.pokedaw.persistence.entities;

public enum Pokeball {

	POKEBALL,SUPERBALL,ULTRABALL
}
