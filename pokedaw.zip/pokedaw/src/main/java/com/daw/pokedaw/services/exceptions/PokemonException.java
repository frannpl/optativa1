package com.daw.pokedaw.services.exceptions;

public class PokemonException extends RuntimeException{

	private static final long serialVersionUID = 8954845870461706054L;
	
	public PokemonException(String message) {
		super(message);
	}
}

