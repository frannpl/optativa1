package com.daw.pokedaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokedawApplicationTests {

	@Test
	void contextLoads() {
	}

}
