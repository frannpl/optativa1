package com.daw.examenFJLP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenFjlpApplicationTests {

	@Test
	void contextLoads() {
	}

}
