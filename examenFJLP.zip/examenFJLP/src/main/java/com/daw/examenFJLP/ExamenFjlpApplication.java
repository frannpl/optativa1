package com.daw.examenFJLP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenFjlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenFjlpApplication.class, args);
	}

}
