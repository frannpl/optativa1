package com.daw.examenFJLP.services.exceptions;


public class RegistroException extends RuntimeException {
    public RegistroException(String message) {
        super(message);
    }
}