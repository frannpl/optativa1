package com.daw.examenFJLP.persistence.entities.enums;

public enum Unidad {
	CELSIUS,FAHRENHEIT;
}
